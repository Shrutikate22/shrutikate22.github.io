// App shell — progress bar, screen transitions, prev/next navigation.
// Each screen advances via its own internal completion handler.

const { useState, useEffect, useRef } = React;

const SCREENS = [
  { id: 'hook',        title: 'The Hook',          short: '01' },
  { id: 'principles',  title: 'Core Principles',   short: '02' },
  { id: 'scenario',    title: 'Scenario Practice', short: '03' },
  { id: 'check',       title: 'Knowledge Check',   short: '04' },
];

function CourseApp() {
  // 0 = title card, 1..4 = screens, 5 = completion (handled inside screen 4)
  const [idx, setIdx] = useState(0);
  const [furthest, setFurthest] = useState(0); // gate forward jumps to what's been unlocked
  const [direction, setDirection] = useState(1); // for transition direction
  const stageRef = useRef(null);

  const total = SCREENS.length;

  const goNext = () => {
    setDirection(1);
    const next = Math.min(idx + 1, total);
    setIdx(next);
    setFurthest(f => Math.max(f, next));
    // scroll the screen pane to top
    requestAnimationFrame(() => {
      if (stageRef.current) stageRef.current.scrollTop = 0;
    });
  };
  const goPrev = () => {
    setDirection(-1);
    setIdx(i => Math.max(0, i - 1));
    requestAnimationFrame(() => {
      if (stageRef.current) stageRef.current.scrollTop = 0;
    });
  };
  const jumpTo = (n) => {
    if (n > furthest) return;
    setDirection(n > idx ? 1 : -1);
    setIdx(n);
    requestAnimationFrame(() => {
      if (stageRef.current) stageRef.current.scrollTop = 0;
    });
  };
  const restart = () => {
    setDirection(-1);
    setIdx(0);
    setFurthest(0);
  };

  // progress: 0% on title, then 25/50/75/100
  const progressPct = idx === 0 ? 0 : (idx / total) * 100;

  return (
    <div className="course-root">
      <TopBar idx={idx} total={total} progressPct={progressPct} furthest={furthest} onJump={jumpTo} />

      <div className="stage" ref={stageRef}>
        <div className={`stage-inner stage-dir-${direction > 0 ? 'fwd' : 'back'}`} key={idx}>
          {idx === 0 && <TitleCard onStart={goNext} />}
          {idx === 1 && <ScreenHook onComplete={goNext} />}
          {idx === 2 && <ScreenPrinciples onComplete={goNext} />}
          {idx === 3 && <ScreenScenario onComplete={goNext} />}
          {idx === 4 && <ScreenCheck onComplete={() => {}} onRestart={restart} />}
        </div>
      </div>

      {idx > 0 && (
        <div className="nav-rail">
          <button className="nav-btn nav-btn--prev" onClick={goPrev} disabled={idx === 0}>
            <span className="nav-arrow" aria-hidden="true">←</span>
            <span className="nav-btn-label">Previous</span>
          </button>
          <div className="nav-meta">
            <span className="nav-meta-num">{String(idx).padStart(2, '0')}</span>
            <span className="nav-meta-divider">/</span>
            <span className="nav-meta-total">{String(total).padStart(2, '0')}</span>
          </div>
        </div>
      )}
    </div>
  );
}

function TopBar({ idx, total, progressPct, furthest, onJump }) {
  return (
    <header className="topbar">
      <div className="topbar-row">
        <div className="brand">
          <div className="brand-mark" aria-hidden="true">
            <svg viewBox="0 0 24 24" width="22" height="22"><path d="M12 3 C 8 8, 5 12, 5 16 a 7 7 0 0 0 14 0 C 19 12, 16 8, 12 3 Z" fill="currentColor"/></svg>
          </div>
          <div className="brand-text">
            <div className="brand-title">Communicating CKD Progression to Patients</div>
            <div className="brand-sub">A short course for care team members &middot; ~10 min</div>
          </div>
        </div>
        <div className="topbar-meta">
          {idx > 0 ? (
            <>
              <span className="topbar-meta-screen">{SCREENS[idx - 1].title}</span>
              <span className="topbar-meta-progress">{Math.round(progressPct)}% complete</span>
            </>
          ) : (
            <span className="topbar-meta-screen">Welcome</span>
          )}
        </div>
      </div>
      <div className="progress-track" role="progressbar" aria-valuenow={Math.round(progressPct)} aria-valuemin="0" aria-valuemax="100">
        <div className="progress-fill" style={{ width: `${progressPct}%` }} />
        <div className="progress-ticks">
          {SCREENS.map((s, i) => {
            const unlocked = i + 1 <= furthest;
            const current = idx === i + 1;
            return (
              <button
                key={s.id}
                className={`progress-tick ${unlocked ? 'is-unlocked' : ''} ${current ? 'is-current' : ''}`}
                style={{ left: `${((i + 1) / total) * 100}%` }}
                onClick={() => onJump(i + 1)}
                disabled={!unlocked}
                aria-label={`Jump to ${s.title}`}
                title={s.title}
              >
                <span className="progress-tick-num">{s.short}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
}

function TitleCard({ onStart }) {
  return (
    <div className="title-card">
      <div className="title-card-grid">
        <div className="title-card-text">
          <div className="kicker">A short interactive course &middot; ~10 minutes</div>
          <h1 className="title-card-h">Communicating CKD progression<br/>to patients.</h1>
          <p className="title-card-deck">
            Most patients leave a kidney appointment understanding less than half of what they were told. This course is about closing that gap &mdash; in the conversations you have this week, not in theory.
          </p>

          <div className="title-card-meta">
            <div className="meta-row">
              <div className="meta-label">For</div>
              <div className="meta-val">Nurses, care coordinators, and other clinical care team members</div>
            </div>
            <div className="meta-row">
              <div className="meta-label">You will</div>
              <div className="meta-val">Recognize the moments where CKD conversations fail &middot; apply three evidence-informed principles &middot; practice in a branching scenario &middot; check your own decision-making</div>
            </div>
            <div className="meta-row">
              <div className="meta-label">Guide</div>
              <div className="meta-val">Dr. Maya, a senior nephrology educator</div>
            </div>
          </div>

          <button className="btn-primary btn-primary--big" onClick={onStart}>
            Begin the course
            <span className="btn-arrow" aria-hidden="true">→</span>
          </button>

          <div className="title-card-modules">
            {SCREENS.map((s, i) => (
              <div key={s.id} className="module-row">
                <span className="module-num">{s.short}</span>
                <span className="module-title">{s.title}</span>
                <span className="module-dur">{['2 min', '3 min', '3 min', '2 min'][i]}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="title-card-art">
          <div className="title-maya-wrap">
            <MayaAvatar expression="warm" gesture="welcome" size={300} />
          </div>
          <div className="title-bubble">
            <div className="title-bubble-name">Dr. Maya</div>
            <p>I&rsquo;m here to walk you through this. We&rsquo;ll spend most of our time on real conversations &mdash; one with a patient named Robert, another with Elena. By the end, you&rsquo;ll have three small moves you can use in your next CKD visit.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

// Mount
const root = ReactDOM.createRoot(document.getElementById('app'));
root.render(<CourseApp />);
