// Dr. Maya — illustrated guide character for the course.
// One consistent face/body; expression + gesture vary per scene.
// Style: flat illustration with light shading, friendly proportions.

const MAYA_COLORS = {
  skin: '#e6b48f',
  skinShade: '#c9966f',
  hair: '#2b1d12',
  hairHi: '#3d2a1b',
  scrub: '#0d9488',     // teal accent — anchors her in the palette
  scrubShade: '#0b756d',
  scrubLine: '#075953',
  white: '#fafaf8',
  ink: '#1a1a1a',
  stethoSteel: '#9aa0a6',
  stethoBlack: '#2a2a2a',
  blush: '#e08a7a',
};

// Expression variants: just the mouth + brows change.
// Gesture variants: change the arm/hand on her right side (viewer's left).
const EXPRESSIONS = {
  warm: { // gentle smile — default
    mouth: <path d="M88,118 Q100,127 112,118" stroke={MAYA_COLORS.ink} fill="none" strokeWidth="2.2" strokeLinecap="round" />,
    browL: <path d="M75,82 Q82,79 90,82" stroke={MAYA_COLORS.hair} strokeWidth="2.8" fill="none" strokeLinecap="round" />,
    browR: <path d="M110,82 Q117,79 125,82" stroke={MAYA_COLORS.hair} strokeWidth="2.8" fill="none" strokeLinecap="round" />,
  },
  bright: { // wider smile — encouraging / celebrating
    mouth: (
      <g>
        <path d="M86,116 Q100,131 114,116 Q100,124 86,116 Z" fill={MAYA_COLORS.ink} />
        <path d="M89,119 Q100,125 111,119" stroke={MAYA_COLORS.white} fill="none" strokeWidth="1.5" strokeLinecap="round" />
      </g>
    ),
    browL: <path d="M74,80 Q82,76 90,80" stroke={MAYA_COLORS.hair} strokeWidth="2.8" fill="none" strokeLinecap="round" />,
    browR: <path d="M110,80 Q118,76 126,80" stroke={MAYA_COLORS.hair} strokeWidth="2.8" fill="none" strokeLinecap="round" />,
  },
  thoughtful: { // slight closed-mouth smile — thinking / coaching
    mouth: <path d="M90,119 Q100,124 110,119" stroke={MAYA_COLORS.ink} fill="none" strokeWidth="2.2" strokeLinecap="round" />,
    browL: <path d="M75,84 Q82,80 90,82" stroke={MAYA_COLORS.hair} strokeWidth="2.8" fill="none" strokeLinecap="round" />,
    browR: <path d="M110,82 Q117,80 125,84" stroke={MAYA_COLORS.hair} strokeWidth="2.8" fill="none" strokeLinecap="round" />,
  },
  concerned: { // gentle, empathetic — for harder moments
    mouth: <path d="M89,120 Q100,123 111,120" stroke={MAYA_COLORS.ink} fill="none" strokeWidth="2.2" strokeLinecap="round" />,
    browL: <path d="M74,85 Q82,80 90,79" stroke={MAYA_COLORS.hair} strokeWidth="2.8" fill="none" strokeLinecap="round" />,
    browR: <path d="M110,79 Q118,80 126,85" stroke={MAYA_COLORS.hair} strokeWidth="2.8" fill="none" strokeLinecap="round" />,
  },
};

// Right arm (viewer's left) — different gestures
const GESTURES = {
  neutral: ( // arm at side, hand resting
    <g>
      <path d="M52,180 C45,200 44,220 48,240 L66,240 C64,220 65,200 70,182 Z" fill={MAYA_COLORS.scrub} />
      <path d="M52,180 C45,200 44,220 48,240" stroke={MAYA_COLORS.scrubLine} strokeWidth="1" fill="none" opacity="0.5" />
      <circle cx="50" cy="232" r="7" fill={MAYA_COLORS.skin} />
    </g>
  ),
  welcome: ( // arm raised, open palm — welcoming
    <g>
      <path d="M58,180 C40,178 22,170 18,150 C16,140 22,134 30,134 C38,134 48,150 60,164 Z" fill={MAYA_COLORS.scrub} />
      <path d="M58,180 C40,178 22,170 18,150" stroke={MAYA_COLORS.scrubLine} strokeWidth="1" fill="none" opacity="0.5" />
      {/* hand — open, palm facing forward */}
      <circle cx="20" cy="138" r="10" fill={MAYA_COLORS.skin} />
      <path d="M14,130 L13,122 M19,128 L19,118 M24,128 L25,118 M28,131 L31,123" stroke={MAYA_COLORS.skinShade} strokeWidth="2.2" strokeLinecap="round" fill="none" />
    </g>
  ),
  point: ( // arm extended forward, index finger up — explaining
    <g>
      <path d="M58,178 C70,168 84,150 92,138 C96,132 100,134 100,140 C100,148 88,168 76,182 Z" fill={MAYA_COLORS.scrub} />
      <circle cx="98" cy="138" r="8" fill={MAYA_COLORS.skin} />
      <path d="M97,131 L97,118" stroke={MAYA_COLORS.skin} strokeWidth="4.5" strokeLinecap="round" />
      <path d="M97,131 L97,118" stroke={MAYA_COLORS.skinShade} strokeWidth="1" strokeLinecap="round" opacity="0.5" />
    </g>
  ),
  chin: ( // hand near chin — thoughtful
    <g>
      <path d="M58,180 C50,170 50,150 60,138 C66,131 76,132 78,142 C80,150 72,168 70,182 Z" fill={MAYA_COLORS.scrub} />
      <circle cx="72" cy="138" r="9" fill={MAYA_COLORS.skin} />
      <path d="M72,130 Q76,126 80,128" stroke={MAYA_COLORS.skinShade} strokeWidth="1.5" fill="none" />
    </g>
  ),
};

function MayaAvatar({ expression = 'warm', gesture = 'neutral', size = 200 }) {
  const e = EXPRESSIONS[expression] || EXPRESSIONS.warm;
  const g = GESTURES[gesture] || GESTURES.neutral;
  return (
    <svg viewBox="0 0 200 240" width={size} height={size * 1.2} xmlns="http://www.w3.org/2000/svg" aria-label="Dr. Maya, your guide" role="img" style={{ display: 'block' }}>
      {/* Body / scrubs — drawn first so head sits on top */}
      <path d="M30,240 L30,200 C30,170 55,148 100,148 C145,148 170,170 170,200 L170,240 Z" fill={MAYA_COLORS.scrub} />
      {/* scrub shoulder shading */}
      <path d="M30,240 L30,200 C30,180 42,162 60,154 L60,240 Z" fill={MAYA_COLORS.scrubShade} opacity="0.35" />
      {/* V-neck */}
      <path d="M82,148 L100,180 L118,148 Z" fill={MAYA_COLORS.white} />
      <path d="M82,148 L100,180 L118,148" stroke={MAYA_COLORS.scrubLine} strokeWidth="1.5" fill="none" />

      {/* Stethoscope — around neck */}
      <path d="M78,150 C70,160 65,175 70,195 L80,205" stroke={MAYA_COLORS.stethoBlack} strokeWidth="3.5" fill="none" strokeLinecap="round" />
      <path d="M122,150 C130,160 135,175 130,195 L120,205" stroke={MAYA_COLORS.stethoBlack} strokeWidth="3.5" fill="none" strokeLinecap="round" />
      <circle cx="100" cy="210" r="8" fill={MAYA_COLORS.stethoSteel} stroke={MAYA_COLORS.stethoBlack} strokeWidth="1.5" />
      <circle cx="100" cy="210" r="3.5" fill={MAYA_COLORS.stethoBlack} />

      {/* ID badge */}
      <rect x="128" y="178" width="28" height="14" rx="1.5" fill={MAYA_COLORS.white} stroke={MAYA_COLORS.scrubLine} strokeWidth="0.5" />
      <rect x="130" y="180" width="24" height="3" fill={MAYA_COLORS.scrub} />
      <text x="142" y="190" textAnchor="middle" fontSize="5" fontFamily="IBM Plex Sans, sans-serif" fontWeight="700" fill={MAYA_COLORS.ink}>DR. MAYA</text>

      {/* Neck */}
      <path d="M88,138 L88,155 Q100,160 112,155 L112,138 Z" fill={MAYA_COLORS.skin} />
      <path d="M88,138 L88,150 Q100,153 112,150 L112,138 Z" fill={MAYA_COLORS.skinShade} opacity="0.3" />

      {/* Hair — back/long */}
      <path d="M58,90 C58,52 142,52 142,90 C142,118 148,158 132,160 L120,148 L80,148 L68,160 C52,158 58,118 58,90 Z" fill={MAYA_COLORS.hair} />

      {/* Face / head */}
      <ellipse cx="100" cy="95" rx="36" ry="42" fill={MAYA_COLORS.skin} />
      {/* gentle face shading on right side */}
      <path d="M100,53 Q136,55 136,95 Q136,127 116,135 Q130,120 132,95 Q130,65 100,57 Z" fill={MAYA_COLORS.skinShade} opacity="0.25" />

      {/* Hair — front bangs (side-swept, soft) */}
      <path d="M64,76 C70,58 96,52 126,58 C138,62 140,76 138,84 C130,72 110,68 92,74 C82,77 72,82 66,90 C63,86 62,80 64,76 Z" fill={MAYA_COLORS.hair} />
      {/* small wisp on forehead */}
      <path d="M88,68 Q96,76 110,72" stroke={MAYA_COLORS.hairHi} strokeWidth="1.2" fill="none" opacity="0.6" />

      {/* Ears */}
      <ellipse cx="63" cy="98" rx="4.5" ry="7" fill={MAYA_COLORS.skin} />
      <ellipse cx="137" cy="98" rx="4.5" ry="7" fill={MAYA_COLORS.skin} />
      <path d="M62,97 Q64,99 62,102" stroke={MAYA_COLORS.skinShade} strokeWidth="1" fill="none" />
      <path d="M138,97 Q136,99 138,102" stroke={MAYA_COLORS.skinShade} strokeWidth="1" fill="none" />
      {/* tiny earring studs */}
      <circle cx="64" cy="103" r="1.2" fill={MAYA_COLORS.stethoSteel} />
      <circle cx="136" cy="103" r="1.2" fill={MAYA_COLORS.stethoSteel} />

      {/* Brows */}
      {e.browL}
      {e.browR}

      {/* Eyes */}
      <ellipse cx="83" cy="95" rx="3.2" ry="4" fill={MAYA_COLORS.ink} />
      <ellipse cx="117" cy="95" rx="3.2" ry="4" fill={MAYA_COLORS.ink} />
      <circle cx="84.2" cy="93.5" r="0.9" fill={MAYA_COLORS.white} />
      <circle cx="118.2" cy="93.5" r="0.9" fill={MAYA_COLORS.white} />
      {/* lashes hint */}
      <path d="M79,91 L80,90 M87,91 L86,90" stroke={MAYA_COLORS.ink} strokeWidth="1" strokeLinecap="round" />
      <path d="M113,91 L114,90 M121,91 L120,90" stroke={MAYA_COLORS.ink} strokeWidth="1" strokeLinecap="round" />

      {/* Nose */}
      <path d="M98,104 Q98,112 102,113" stroke={MAYA_COLORS.skinShade} strokeWidth="1.5" fill="none" strokeLinecap="round" />

      {/* Cheeks — subtle blush */}
      <ellipse cx="74" cy="110" rx="6" ry="3" fill={MAYA_COLORS.blush} opacity="0.28" />
      <ellipse cx="126" cy="110" rx="6" ry="3" fill={MAYA_COLORS.blush} opacity="0.28" />

      {/* Mouth */}
      {e.mouth}

      {/* Gesture (arm) drawn LAST so it sits in front of body */}
      {g}
    </svg>
  );
}

// Speech bubble + Maya combined. Anchored layout: avatar left, bubble right.
function MayaPanel({ expression, gesture, children, size = 'md' }) {
  const avatarSize = size === 'lg' ? 220 : size === 'sm' ? 130 : 170;
  return (
    <div className={`maya-panel maya-panel--${size}`}>
      <div className="maya-avatar-wrap">
        <MayaAvatar expression={expression} gesture={gesture} size={avatarSize} />
      </div>
      <div className="maya-bubble">
        <div className="maya-bubble-tail" aria-hidden="true"></div>
        <div className="maya-bubble-name">Dr. Maya</div>
        <div className="maya-bubble-body">{children}</div>
      </div>
    </div>
  );
}

Object.assign(window, { MayaAvatar, MayaPanel, MAYA_COLORS });
