// Four screens of the course. Each is a self-contained component.
// Screens manage their own internal interaction state (which option clicked,
// which card revealed, etc). The shell handles navigation between screens.

const { useState } = React;

// ============================================================
// SCREEN 1 — Hook
// A real patient quote + diagnostic "what went wrong" question.
// ============================================================
function ScreenHook({ onComplete }) {
  const [picked, setPicked] = useState(null);

  const options = [
    {
      id: 'patient',
      label: 'Robert wasn’t paying close enough attention during his appointment.',
      correct: false,
      feedback: 'This places the burden on the patient — but research on health literacy is clear: up to 9 in 10 adults struggle with health information at some point. The responsibility for clear communication sits with us.',
    },
    {
      id: 'clinician',
      label: 'The clinician used clinical terms like "GFR" and "stages" without checking that Robert understood them.',
      correct: true,
      feedback: 'Exactly. Unchecked jargon is the most common reason patients leave appointments confused. Robert nodded because he didn’t want to seem uninformed — a pattern clinicians see every day. The fix isn’t simpler patients; it’s clearer communication.',
    },
  ];

  const ready = picked !== null;
  const pickedOpt = options.find(o => o.id === picked);

  return (
    <div className="screen screen-hook">
      <div className="screen-grid">
        <aside className="screen-side">
          <MayaPanel expression="concerned" gesture="welcome">
            <p>Welcome. Before we get into frameworks, I want you to meet Robert.</p>
            <p>He came home from his nephrologist last week and said this to his wife. Read it slowly. <strong>What do you notice?</strong></p>
          </MayaPanel>
        </aside>

        <main className="screen-main">
          <div className="kicker">Scenario 01 — The Hook</div>
          <h1 className="screen-title">What happens after the appointment ends.</h1>

          <figure className="patient-quote">
            <div className="patient-quote-mark" aria-hidden="true">&ldquo;</div>
            <blockquote>
              He said something about my <em>GFR</em> going down, and stages, and that I might need&hellip; I don’t know what. I just nodded. I didn’t want to seem stupid.
              <br /><br />
              Now I’m scared and I have no idea what’s actually happening to me.
            </blockquote>
            <figcaption>
              <span className="patient-quote-name">Robert, 64</span>
              <span className="patient-quote-sub">two days after his nephrology appointment</span>
            </figcaption>
          </figure>

          <div className="prompt">
            <div className="prompt-label">Your turn</div>
            <h2 className="prompt-q">What went wrong here?</h2>
            <div className="option-list">
              {options.map(opt => {
                const isPicked = picked === opt.id;
                const showState = picked !== null;
                const cls = ['option',
                  showState && opt.correct ? 'option--correct' : '',
                  showState && isPicked && !opt.correct ? 'option--incorrect' : '',
                  showState && !isPicked ? 'option--dim' : '',
                ].filter(Boolean).join(' ');
                return (
                  <button
                    key={opt.id}
                    className={cls}
                    disabled={picked !== null}
                    onClick={() => setPicked(opt.id)}
                  >
                    <span className="option-letter">{opt.id === 'patient' ? 'A' : 'B'}</span>
                    <span className="option-text">{opt.label}</span>
                    {showState && opt.correct && <span className="option-tag">Best answer</span>}
                    {showState && isPicked && !opt.correct && <span className="option-tag option-tag--no">Not quite</span>}
                  </button>
                );
              })}
            </div>

            {pickedOpt && (
              <div className={`feedback ${pickedOpt.correct ? 'feedback--good' : 'feedback--reflect'}`}>
                <div className="feedback-header">
                  <MayaAvatar expression={pickedOpt.correct ? 'bright' : 'thoughtful'} gesture="neutral" size={70} />
                  <div>
                    <div className="feedback-name">Dr. Maya</div>
                    <div className="feedback-label">{pickedOpt.correct ? 'You’ve got it.' : 'Let’s reframe.'}</div>
                  </div>
                </div>
                <p>{pickedOpt.feedback}</p>
                <p className="feedback-bridge">In the next section, we’ll look at three evidence-informed principles that prevent moments like Robert’s from happening.</p>
              </div>
            )}
          </div>
        </main>
      </div>

      <ScreenFooter ready={ready} onNext={onComplete} nextLabel="Continue to the principles" />
    </div>
  );
}

// ============================================================
// SCREEN 2 — Core Concept: Three Principles
// Click each card to reveal its content. After all three are explored,
// Maya reacts and Next unlocks.
// ============================================================
function ScreenPrinciples({ onComplete }) {
  const [opened, setOpened] = useState(new Set());

  const principles = [
    {
      id: 'plain',
      num: '01',
      title: 'Use plain language',
      hint: 'Translate clinical terms into the words your patient already uses.',
      body: 'Patients can’t act on information they don’t understand. Replace clinical shorthand with everyday phrasing — even when it feels less precise to you. Precision means nothing if the patient leaves the room confused.',
      example: {
        bad: '“Your eGFR has declined to 44, placing you in stage 3b. We’ll need to monitor your albuminuria.”',
        good: '“Your kidneys are working at about 44% of normal. That’s in a range we call ‘stage 3b.’ I want to keep an eye on a sign of stress in your kidneys called protein in the urine — we’ll check it again in three months.”',
      },
    },
    {
      id: 'teachback',
      num: '02',
      title: 'Use teach-back to confirm understanding',
      hint: 'Ask the patient to explain it back in their own words.',
      body: '“Do you understand?” almost always gets a yes — patients don’t want to seem uninformed. Teach-back surfaces what the patient actually heard, gives you a chance to clarify gaps, and signals that <em>you</em> are responsible for the explanation, not them.',
      example: {
        bad: '“Does that all make sense?”',
        good: '“I gave you a lot just now. To make sure I explained it well — can you tell me, in your own words, what stage 3 means for you and what we’re doing about it?”',
      },
    },
    {
      id: 'emotion',
      num: '03',
      title: 'Acknowledge emotion first',
      hint: 'Name the feeling before you deliver more information.',
      body: 'A patient hearing “your kidney function is declining” is often not in a state to absorb clinical detail. Acknowledging emotion isn’t a soft skill — it is what makes the rest of the conversation possible. Skip this step and the next ten minutes of education will not land.',
      example: {
        bad: '“The good news is dialysis isn’t something we’re considering right now. Your eGFR is…”',
        good: '“I can hear that this has been weighing on you. Before we go through the numbers, I want to make sure I understand what’s worrying you most.”',
      },
    },
  ];

  const toggle = (id) => {
    setOpened(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const allOpen = principles.every(p => opened.has(p.id));

  return (
    <div className="screen screen-principles">
      <div className="screen-grid">
        <aside className="screen-side">
          <MayaPanel expression={allOpen ? 'bright' : 'warm'} gesture={allOpen ? 'neutral' : 'point'}>
            {!allOpen ? (
              <>
                <p>There are dozens of communication frameworks for clinicians. These three are the ones I come back to most when I&rsquo;m coaching staff on CKD conversations.</p>
                <p><strong>Tap each card to explore it.</strong> All three before you move on.</p>
              </>
            ) : (
              <>
                <p>Good. Notice that these aren&rsquo;t three separate skills &mdash; they work together. Plain language gives the patient something to grasp. Teach-back confirms they actually grasped it. And acknowledging emotion is what makes either of those possible.</p>
                <p>Let&rsquo;s see you put them to use.</p>
              </>
            )}
          </MayaPanel>
        </aside>

        <main className="screen-main">
          <div className="kicker">Section 02 — Core Concept</div>
          <h1 className="screen-title">Three principles for talking about CKD progression.</h1>
          <p className="screen-deck">Each is well-supported in the patient communication literature. Each is also small enough to use in your next conversation.</p>

          <div className="principle-grid">
            {principles.map(p => {
              const isOpen = opened.has(p.id);
              return (
                <article key={p.id} className={`principle-card ${isOpen ? 'is-open' : ''}`}>
                  <button className="principle-head" onClick={() => toggle(p.id)} aria-expanded={isOpen}>
                    <span className="principle-num">{p.num}</span>
                    <span className="principle-title">{p.title}</span>
                    <span className="principle-chev" aria-hidden="true">
                      <svg viewBox="0 0 16 16" width="16" height="16"><path d="M3 6 L8 11 L13 6" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" /></svg>
                    </span>
                  </button>
                  {!isOpen && (
                    <div className="principle-hint">{p.hint}</div>
                  )}
                  {isOpen && (
                    <div className="principle-body">
                      <p dangerouslySetInnerHTML={{ __html: p.body }} />
                      <div className="example-block">
                        <div className="example-row example-row--bad">
                          <div className="example-tag">Avoid</div>
                          <div className="example-text">{p.example.bad}</div>
                        </div>
                        <div className="example-row example-row--good">
                          <div className="example-tag">Try instead</div>
                          <div className="example-text">{p.example.good}</div>
                        </div>
                      </div>
                    </div>
                  )}
                </article>
              );
            })}
          </div>

          <div className="progress-pips">
            {principles.map(p => (
              <span key={p.id} className={`pip ${opened.has(p.id) ? 'pip--filled' : ''}`} aria-label={opened.has(p.id) ? 'Explored' : 'Not yet explored'} />
            ))}
            <span className="progress-pips-label">
              {opened.size} of 3 explored
            </span>
          </div>
        </main>
      </div>

      <ScreenFooter ready={allOpen} onNext={onComplete} nextLabel="Practice in a real conversation" hint={allOpen ? null : 'Explore all three principles to continue.'} />
    </div>
  );
}

// ============================================================
// SCREEN 3 — Branching Scenario
// You play a care coordinator with Mrs. Elena Reyes (Stage 3 CKD).
// Two decision points; consequences shown via her reaction.
// ============================================================
function ScreenScenario({ onComplete }) {
  const [step, setStep] = useState(0); // 0..4
  const [choice1, setChoice1] = useState(null);
  const [choice2, setChoice2] = useState(null);

  // Step 0: intro -> 1: decision1 -> 2: feedback1 -> 3: decision2 -> 4: feedback2/end
  const goto = (n) => setStep(n);

  return (
    <div className="screen screen-scenario">
      <div className="screen-grid">
        <aside className="screen-side">
          <MayaPanel
            expression={step === 0 ? 'warm' : step === 2 ? 'thoughtful' : step === 4 ? 'bright' : 'thoughtful'}
            gesture={step === 0 ? 'welcome' : step === 4 ? 'neutral' : 'chin'}
          >
            {step === 0 && <>
              <p>Time to step into the room. You&rsquo;re the care coordinator. Your patient is <strong>Elena Reyes</strong>, 58, with stage 3 CKD. Her latest labs came back this morning.</p>
              <p>Read carefully. Your words matter here.</p>
            </>}
            {step === 1 && <>
              <p>Elena&rsquo;s first words tell you what she&rsquo;s most afraid of. <strong>What you say next will shape the rest of the visit.</strong></p>
            </>}
            {step === 2 && choice1 && <>
              {choice1 === 'numbers' ? (
                <p>Notice what happened. You answered her question accurately, but you led with numbers and used the word she&rsquo;s most afraid of. Let&rsquo;s try the next moment differently.</p>
              ) : (
                <p>That&rsquo;s the move. You named the worry, slowed the room down, and put a boundary on the fear before delivering information. Watch how this changes everything that follows.</p>
              )}
            </>}
            {step === 3 && <>
              <p>You&rsquo;ve explained stage 3 in plain language. Elena&rsquo;s quiet, processing. <strong>How will you check that what you said actually landed?</strong></p>
            </>}
            {step === 4 && <>
              <p>That&rsquo;s a wrap on Elena&rsquo;s visit. The same three principles, used in one short conversation. You won&rsquo;t do this perfectly every time &mdash; nobody does. The goal is to notice your patterns, and choose intentionally.</p>
            </>}
          </MayaPanel>
        </aside>

        <main className="screen-main">
          <div className="kicker">Section 03 — Scenario Practice</div>
          <h1 className="screen-title">A conversation with Elena.</h1>

          <PatientCard />

          {step === 0 && (
            <div className="scenario-step">
              <div className="scene">
                <div className="scene-stage">The waiting room intake is done. You walk Elena back to the exam room. She sits down, holding a printed copy of her lab results, and looks up at you.</div>
              </div>
              <button className="btn-primary" onClick={() => goto(1)}>Begin the conversation</button>
            </div>
          )}

          {step >= 1 && (
            <div className="dialogue">
              <DialogueLine who="elena">The nurse said my numbers got worse. Am I going to need dialysis?</DialogueLine>

              {step === 1 && (
                <DecisionBlock
                  label="Decision 01 — Your response"
                  options={[
                    { id: 'numbers', text: '"Your eGFR went from 52 to 44, which is still in stage 3. Dialysis isn’t typically considered until much later."' },
                    { id: 'emotion', text: '"I can hear that’s been weighing on you. Let’s slow down — I’ll walk you through what changed and what it means. Most people at this stage are nowhere near needing dialysis."' },
                  ]}
                  onPick={(id) => { setChoice1(id); goto(2); }}
                />
              )}

              {step >= 2 && choice1 && (
                <DialogueLine who="you" choice={choice1 === 'numbers' ? 'less-good' : 'good'}>
                  {choice1 === 'numbers'
                    ? '"Your eGFR went from 52 to 44, which is still in stage 3. Dialysis isn’t typically considered until much later."'
                    : '"I can hear that’s been weighing on you. Let’s slow down — I’ll walk you through what changed and what it means. Most people at this stage are nowhere near needing dialysis."'
                  }
                </DialogueLine>
              )}

              {step >= 2 && choice1 === 'numbers' && (
                <>
                  <DialogueLine who="elena" mood="anxious">"Oh. Okay."</DialogueLine>
                  <div className="reaction-note">
                    <strong>What you saw:</strong> Elena nods, looks down at her paper, and goes quiet. She heard the word she was afraid of and a string of numbers. She didn&rsquo;t hear reassurance.
                  </div>
                </>
              )}
              {step >= 2 && choice1 === 'emotion' && (
                <>
                  <DialogueLine who="elena" mood="relieved">"Thank you. I&rsquo;ve been worrying about that since the lab called me back. I didn&rsquo;t sleep."</DialogueLine>
                  <div className="reaction-note reaction-note--good">
                    <strong>What you saw:</strong> Elena&rsquo;s shoulders drop. She makes eye contact. You&rsquo;ve given her permission to be scared, and you&rsquo;ve given her a number to hold onto: <em>not now, not soon</em>.
                  </div>
                </>
              )}

              {step >= 2 && step < 3 && (
                <button className="btn-primary" onClick={() => goto(3)}>Continue</button>
              )}

              {step >= 3 && (
                <>
                  <div className="time-marker">A few minutes later — you&rsquo;ve walked through what stage 3 means in plain language.</div>
                  <DialogueLine who="you" narration>You set down the diagram you&rsquo;ve been drawing. Elena is quiet.</DialogueLine>

                  {step === 3 && (
                    <DecisionBlock
                      label="Decision 02 — Checking understanding"
                      options={[
                        { id: 'closed', text: '"Does that all make sense?"' },
                        { id: 'teach', text: '"I just gave you a lot. To make sure I explained it well — can you tell me, in your own words, what stage 3 means for you?"' },
                      ]}
                      onPick={(id) => { setChoice2(id); goto(4); }}
                    />
                  )}

                  {step >= 4 && choice2 && (
                    <DialogueLine who="you" choice={choice2 === 'closed' ? 'less-good' : 'good'}>
                      {choice2 === 'closed'
                        ? '"Does that all make sense?"'
                        : '"I just gave you a lot. To make sure I explained it well — can you tell me, in your own words, what stage 3 means for you?"'
                      }
                    </DialogueLine>
                  )}

                  {step >= 4 && choice2 === 'closed' && (
                    <>
                      <DialogueLine who="elena">"Yeah, I think so."</DialogueLine>
                      <div className="reaction-note">
                        <strong>What you saw:</strong> Elena says yes. She almost always will. You don&rsquo;t actually know what she understood, what she misheard, or what she&rsquo;ll be Googling at 11 p.m. tonight. The teach-back method exists exactly to surface that gap.
                      </div>
                    </>
                  )}
                  {step >= 4 && choice2 === 'teach' && (
                    <>
                      <DialogueLine who="elena" mood="relieved">"It means my kidneys are working at about half&hellip; and I should keep an eye on my blood pressure. And what I eat. Right?"</DialogueLine>
                      <div className="reaction-note reaction-note--good">
                        <strong>What you saw:</strong> Two sentences just told you exactly what landed. The salt piece landed. The protein piece didn&rsquo;t make it in. You now know what to revisit before she walks out the door &mdash; without making her feel quizzed.
                      </div>
                    </>
                  )}
                </>
              )}
            </div>
          )}
        </main>
      </div>

      <ScreenFooter ready={step >= 4} onNext={onComplete} nextLabel="Take the knowledge check" />
    </div>
  );
}

function PatientCard() {
  return (
    <div className="patient-card">
      <div className="patient-card-avatar" aria-hidden="true">
        {/* abstract avatar — no stock photo */}
        <svg viewBox="0 0 60 60" width="60" height="60">
          <circle cx="30" cy="30" r="30" fill="#e5e7eb" />
          <circle cx="30" cy="24" r="9" fill="#9ca3af" />
          <path d="M10,55 C10,42 22,38 30,38 C38,38 50,42 50,55 Z" fill="#9ca3af" />
        </svg>
      </div>
      <div className="patient-card-info">
        <div className="patient-card-name">Elena Reyes</div>
        <div className="patient-card-meta">58 years old &middot; Stage 3 CKD &middot; Visit type: lab follow-up</div>
        <div className="patient-card-labs">
          <span className="lab-pill"><span className="lab-pill-k">eGFR</span><span className="lab-pill-v">44</span><span className="lab-pill-d">was 52</span></span>
          <span className="lab-pill"><span className="lab-pill-k">BP</span><span className="lab-pill-v">138/86</span></span>
          <span className="lab-pill"><span className="lab-pill-k">UACR</span><span className="lab-pill-v">38</span></span>
        </div>
      </div>
    </div>
  );
}

function DialogueLine({ who, children, mood, choice, narration }) {
  if (narration) {
    return <div className="dialogue-narration">{children}</div>;
  }
  return (
    <div className={`dialogue-line dialogue-line--${who} ${mood ? `mood-${mood}` : ''} ${choice ? `choice-${choice}` : ''}`}>
      <div className="dialogue-tag">{who === 'elena' ? 'Elena' : 'You'}</div>
      <div className="dialogue-body">{children}</div>
    </div>
  );
}

function DecisionBlock({ label, options, onPick }) {
  return (
    <div className="decision-block">
      <div className="decision-label">{label}</div>
      <div className="decision-options">
        {options.map((o, i) => (
          <button key={o.id} className="decision-option" onClick={() => onPick(o.id)}>
            <span className="decision-letter">{i === 0 ? 'A' : 'B'}</span>
            <span className="decision-text">{o.text}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

// ============================================================
// SCREEN 4 — Knowledge Check
// 2 questions, immediate rationale, score + Maya closing.
// ============================================================
function ScreenCheck({ onComplete, onRestart }) {
  const [answers, setAnswers] = useState({}); // {q1: 'b', q2: 'b'}
  const [done, setDone] = useState(false);

  const questions = [
    {
      id: 'q1',
      kind: 'mc',
      stem: 'Which response is the strongest example of the teach-back method?',
      options: [
        { id: 'a', text: '"Do you have any questions for me?"', correct: false, rationale: 'A reasonable invitation — but it doesn’t reveal what the patient understood. Many patients say "no questions" even when they’re confused.' },
        { id: 'b', text: '"Just to make sure I explained that well — can you tell me in your own words what we just talked about?"', correct: true, rationale: 'Yes. Notice the framing: you, not the patient, are responsible for the explanation. That phrasing protects the patient from feeling tested.' },
        { id: 'c', text: '"Does that all make sense?"', correct: false, rationale: 'A yes/no question. Almost every patient says yes — not because they understood, but because they don’t want to seem uninformed.' },
        { id: 'd', text: '"I’ll send you home with a pamphlet that covers all of this."', correct: false, rationale: 'Print materials are useful as a supplement, but they don’t confirm understanding in the room with you. Teach-back happens face to face.' },
      ],
    },
    {
      id: 'q2',
      kind: 'scenario',
      stem: 'A patient pauses, looks down, and says quietly, "I just feel like I can’t keep up with all of this." What’s your best next response?',
      options: [
        { id: 'a', text: '"Don’t worry, we’ll get through this together."', correct: false, rationale: 'Well-intentioned, but it skips past the feeling she just shared. "Don’t worry" is a polite way to say "stop telling me how you feel."' },
        { id: 'b', text: '"That’s a really common reaction. What feels most overwhelming right now?"', correct: true, rationale: 'You named the feeling, normalized it, and opened a question that lets her tell you exactly where to focus. Acknowledgment first, then information.' },
        { id: 'c', text: '"Let me walk you through the next steps so it feels more manageable."', correct: false, rationale: 'Jumping straight to action skips the emotional acknowledgment she signaled she needed. The information won’t land while she’s still flooded.' },
        { id: 'd', text: '"Here’s a brochure that breaks all of this down."', correct: false, rationale: 'Defers the conversation onto paper. She told you she’s overwhelmed; more text won’t fix that.' },
      ],
    },
  ];

  const pick = (qid, oid) => {
    if (answers[qid]) return; // lock once chosen
    setAnswers(prev => ({ ...prev, [qid]: oid }));
  };

  const score = questions.filter(q => {
    const a = answers[q.id];
    return a && q.options.find(o => o.id === a)?.correct;
  }).length;

  const bothAnswered = questions.every(q => answers[q.id]);

  return (
    <div className="screen screen-check">
      <div className="screen-grid">
        <aside className="screen-side">
          <MayaPanel
            expression={done ? 'bright' : 'warm'}
            gesture={done ? 'welcome' : 'point'}
          >
            {!done && !bothAnswered && <>
              <p>Two questions. There&rsquo;s no time pressure &mdash; this isn&rsquo;t about getting them right on the first try. It&rsquo;s about noticing which option you reach for.</p>
            </>}
            {!done && bothAnswered && <>
              <p>You&rsquo;ve answered both. Take a moment with the rationale, then close out below when you&rsquo;re ready.</p>
            </>}
            {done && <>
              <p>That&rsquo;s a wrap.</p>
              <p>Whatever your score, the goal isn&rsquo;t a perfect record. It&rsquo;s noticing your own patterns and choosing, on purpose, the words your patient needs to hear.</p>
              <p>The conversations you have with patients like Robert and Elena will shape how they live with this diagnosis. Thank you for the care you bring to this work.</p>
              <p className="maya-sign">&mdash; Dr. Maya</p>
            </>}
          </MayaPanel>
        </aside>

        <main className="screen-main">
          <div className="kicker">Section 04 — Knowledge Check</div>
          <h1 className="screen-title">Two quick checks before you go.</h1>

          {questions.map((q, qi) => {
            const userAns = answers[q.id];
            const userOpt = userAns ? q.options.find(o => o.id === userAns) : null;
            return (
              <div key={q.id} className="quiz-q">
                <div className="quiz-q-num">Question {qi + 1} of 2 <span className="quiz-q-kind">{q.kind === 'mc' ? 'Multiple choice' : 'Scenario'}</span></div>
                <h2 className="quiz-stem">{q.stem}</h2>
                <div className="quiz-options">
                  {q.options.map(opt => {
                    const isPicked = userAns === opt.id;
                    const showState = !!userAns;
                    const cls = ['quiz-option',
                      showState && opt.correct ? 'quiz-option--correct' : '',
                      showState && isPicked && !opt.correct ? 'quiz-option--incorrect' : '',
                      showState && !isPicked && !opt.correct ? 'quiz-option--dim' : '',
                    ].filter(Boolean).join(' ');
                    return (
                      <button
                        key={opt.id}
                        className={cls}
                        disabled={!!userAns}
                        onClick={() => pick(q.id, opt.id)}
                      >
                        <span className="quiz-letter">{opt.id.toUpperCase()}</span>
                        <span className="quiz-text">{opt.text}</span>
                      </button>
                    );
                  })}
                </div>
                {userOpt && (
                  <div className={`quiz-rationale ${userOpt.correct ? 'quiz-rationale--good' : 'quiz-rationale--no'}`}>
                    <div className="quiz-rationale-head">{userOpt.correct ? 'Correct' : 'Worth a second look'}</div>
                    <p>{userOpt.rationale}</p>
                    {!userOpt.correct && (
                      <p className="quiz-rationale-correct"><strong>Best answer:</strong> <em>{q.options.find(o => o.correct).text}</em></p>
                    )}
                  </div>
                )}
              </div>
            );
          })}

          {bothAnswered && !done && (
            <button className="btn-primary btn-primary--big" onClick={() => setDone(true)}>See my results</button>
          )}

          {done && (
            <div className="score-card">
              <div className="score-card-bar">
                <div className="score-card-fill" style={{ width: `${(score / 2) * 100}%` }} />
              </div>
              <div className="score-card-row">
                <div>
                  <div className="score-card-label">Your score</div>
                  <div className="score-card-num">{score} <span>/ 2</span></div>
                </div>
                <div className="score-card-msg">
                  {score === 2 && 'Both correct. You’ve internalized the moves — now bring them into your next CKD conversation this week.'}
                  {score === 1 && 'One out of two. Look back at the rationale; pick one principle to deliberately use this week.'}
                  {score === 0 && 'Re-read the rationale carefully. These are habits, not facts — they’ll take a few real conversations to settle in.'}
                </div>
              </div>
              <div className="score-card-actions">
                <button className="btn-ghost" onClick={onRestart}>Restart course</button>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

// ============================================================
// Shared screen footer (Next button)
// ============================================================
function ScreenFooter({ ready, onNext, nextLabel, hint }) {
  return (
    <div className="screen-footer">
      {hint && !ready && <div className="screen-hint">{hint}</div>}
      <button className={`btn-primary ${!ready ? 'btn-primary--disabled' : ''}`} disabled={!ready} onClick={onNext}>
        {nextLabel}
        <span className="btn-arrow" aria-hidden="true">&rarr;</span>
      </button>
    </div>
  );
}

Object.assign(window, { ScreenHook, ScreenPrinciples, ScreenScenario, ScreenCheck });
