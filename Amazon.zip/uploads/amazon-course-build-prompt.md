# Master Build Prompt — Amazon NAEF Interactive eLearning Course
### Paste this into Claude.ai (Artifacts enabled) to build each deliverable

---

## CONTEXT BLOCK — Include this at the top of every prompt

```
I am building a professional eLearning portfolio piece for an Amazon Learning Experience Designer
interview. The course is for Amazon's North America External Fulfillment (NAEF) L&D team and maps
directly to their 2026 strategic priority of quality defect reduction. All three deliverables
below must feel like real enterprise-grade L&D work — not demos or prototypes.

COURSE OVERVIEW
Topic: Quality defect prevention at Amazon FC (fulfillment center) stations
Audience: FC associates at pick, pack, and stow stations across NAEF sites
Duration: ~12–15 minutes
Framework: VID Check (Verify → Inspect → Decide)
Setting: Live Amazon fulfillment center floor — conveyor belts, shelving units, scan guns,
         cardboard boxes, warehouse lighting
Instructor avatar: "Alex" — a senior FC associate and peer trainer, not a talking head.
                   Alex wears an Amazon FC vest, speaks in plain operational language,
                   and appears at key moments to coach, debrief scenarios, and reinforce decisions.
```

---

## DELIVERABLE 1 — INTERACTIVE eLEARNING COURSE (HTML Artifact)

### Paste this prompt to build the course:

```
Build a production-grade interactive eLearning course as a single self-contained HTML file.
This is a portfolio piece for an Amazon Learning Experience Designer interview — it must look
and function like real enterprise eLearning. Use the context block above.

VISUAL DESIGN DIRECTION
- Aesthetic: Industrial-warm. Dark FC environment (deep charcoal #1A1E2B backgrounds) with
  warm amber (#E8A020) as the primary accent. Teal (#1A7A5E) for success/correct states.
  Clean white cards for content panels that "float" over the warehouse environment.
- Setting: Every screen should feel like it's set inside an Amazon FC. Use CSS to create a
  subtle warehouse backdrop on each slide: rendered with SVG or CSS — conveyor belt lines,
  shelf silhouettes, ambient warehouse lighting glow, scan gun icons.
- Typography: Use Google Fonts — "DM Serif Display" for course title and scenario headers,
  "DM Sans" for all body text and UI elements.
- Instructor "Alex": Render as a stylized SVG avatar in the bottom-left or right corner of
  key slides. Alex wears an orange FC vest, has a friendly expression, and changes pose/
  expression based on the slide type (coaching = leaning forward, feedback = thumbs up/down,
  intro = waving). Alex speaks in speech bubbles with plain language.

COURSE ARCHITECTURE — 9 SCREENS

Screen 1 — TITLE / HOOK
- Full dark immersive screen. Animated SVG conveyor belt moving slowly in the background.
- Large text: "Catch It Before It Ships." (DM Serif Display, white, large)
- Subhead: "Quality defect prevention for NAEF associates"
- 3 stat chips: "~60% of defects are preventable at point of handling" /
  "10 defects per 1,000 units escape without a structured check" / "30 seconds is all it takes"
- Alex avatar waves from the corner with speech bubble: "I've been on this floor for 4 years.
  This one decision changed how I work every single day."
- CTA button: "Start Module →" (amber, bold)
- Animated progress bar at top (9 steps, dot indicators)

Screen 2 — MEET ALEX (Instructor Introduction)
- Alex steps forward (larger SVG avatar, center or left-aligned)
- Alex's speech: "I'm Alex — I've been training new associates at this site for three years.
  Before I had the VID Check, I shipped three defective items in one week during Peak. Let me
  show you what I learned."
- Below Alex: Two-column layout showing "What goes wrong without a check" vs.
  "What changes with the VID Check" — icon-based contrast panel
- Button: "Meet the VID Check →"

Screen 3 — THE VID CHECK FRAMEWORK
- 3-card animated reveal: V → I → D cards appear sequentially with stagger animation
- Each card has: a large serif letter, the step name, a plain-language description,
  and a small warehouse-context icon (barcode for Verify, magnifying glass for Inspect,
  decision fork for Decide)
- Below the 3 cards: "Decision table" showing when to Release / Fix / Flag with visual icons
- Alex in corner: "This takes 30 seconds. I've timed it. It's worth it every time."
- Button: "Practice it in two real scenarios →"

Screen 4 — SCENARIO 1 SETUP: "The Dented Box"
- FULL IMMERSIVE LAYOUT: Animated warehouse background with conveyor belt moving.
  A 3D-style rendered box (CSS/SVG) with a visible dent on the corner is shown on the belt.
- Scene label: "📍 Pack station — Tuesday afternoon — 8% below rate target"
- Narrative text over the scene in a floating dark card:
  "You're at the pack station. You pick up a small electronics item. The outer box has a
  clear dent on one corner. The item inside might be fine — you can't tell without opening.
  Your rate monitor shows 8% below target."
- Alex (small, lower corner) speech bubble: "I've been here. What do you do?"
- Pressure indicator: Animated rate-monitor widget showing 8% below (red bar, blinking)
- Button: "Make your decision →" (transitions to choice screen)

Screen 5 — SCENARIO 1 DECISION POINT
- Three branching choices rendered as large clickable cards (not radio buttons):
  Choice A: Icon of box moving forward → "Pack it — a dent on the outside doesn't mean
             the inside is damaged"
  Choice B: Icon of VID Check checklist → "Apply the VID Check before making a call"
  Choice C: Icon of manager figure → "Flag it immediately to my manager without checking"
- Each card has a hover state (lifts, border glow)
- Clicking locks the other two out, dims them, and reveals consequence + feedback
- BRANCHING FEEDBACK (appears below after selection, NOT a new screen):
  Choice A → Wrong: Red tint on card, animated defect icon appears, feedback text:
    "This is how a defect escapes. Packaging damage is one of the top 3 defect triggers.
    A dent can signal internal damage you can't see. This item needed a VID Check."
    Alex appears: "I made this call once. The customer got a broken tablet. It costs more
    than 30 seconds."
  Choice B → Correct: Teal tint, checkmark animation, feedback text:
    "Exactly right. You verified the item matched. You inspected — and found the corner dent
    had compromised the internal seal. You flagged it. One defect stopped in 30 seconds."
    Alex: "That's the VID Check working. Every time."
  Choice C → Partial: Amber tint, feedback text:
    "Not wrong — but not optimal. The VID Check often answers the question before your
    manager needs to be involved. Run the check first, then escalate if needed."
- "Continue to Scenario 2 →" button appears after any choice is made

Screen 6 — SCENARIO 2 SETUP: "The Peak Crunch"
- FULL IMMERSIVE LAYOUT: Conveyor belt moves FASTER (CSS animation speed increased).
  Multiple boxes visible. "PEAK SEASON" banner in amber at top of warehouse scene.
- Scene: Stow station. Item with torn seal visible on shelf.
- Pressure stack visual: Three overlapping "pressure indicators":
  ① Volume gauge: 140% of normal (red)
  ② Rate mentions from manager: 2 today (amber)  
  ③ Social: Animated figure of next associate waiting
- Alex (anxious expression variant): "Peak is when everything feels different. It isn't."
- Narrative: "Volume is 40% above normal. Your manager has mentioned rate targets twice today.
  You're at stow and notice an item with a torn seal. The next associate is waiting."

Screen 7 — SCENARIO 2 DECISION POINT
- Same branching card layout as Scenario 1
  Choice A: "Stow it — downstream QA will catch any real problem"
  Choice B: "Apply the VID Check — 30 seconds now prevents a return later"
  Choice C: "Ask the next associate to check it while I keep moving"
- BRANCHING FEEDBACK:
  Choice A → Wrong: "QA catches fewer than 60% of defects that leave the station.
    'Downstream will catch it' is how defects escape. The cost lands on the customer."
    Alex: "I used to say this to myself during Peak. Then I tracked it. 60%. That changed me."
  Choice B → Correct: "This is it. Under pressure is when the VID Check matters most.
    You applied it when it was hardest. That's what turns a check into a behavior."
    Alex: "This one — right here — is why I still do it every shift, four years in."
  Choice C → Wrong: "Delegating a quality check creates confusion about who checked what.
    The VID Check is your responsibility at your station. Passing ambiguity down the line
    is how defects escape."

Screen 8 — KNOWLEDGE CHECK (Interactive Quiz)
- Two questions with animated reveal
- Question 1 (multiple choice):
  "Which VID Check step confirms the item ID and quantity match the order?"
  Options: A) Verify  B) Inspect  C) Decide
  Correct: A — green confirmation + brief explanation appears inline
  Wrong: red highlight + "Let's revisit — Verify is the first step: confirm the order match
         before checking anything else."
- Question 2 (true/false styled as two large cards):
  "During high-volume periods, it's acceptable to skip the VID Check if you're behind on rate."
  Cards: TRUE (red, crossed box icon) / FALSE (teal, checkmark)
  Correct: FALSE — confirmation: "Volume pressure is when quality decisions are hardest AND
           most important. The VID Check is a 30-second decision — not a rate risk."
- Score display after both answered: "2/2 ✓" or "1/2 — review the VID Check before returning
  to the floor"
- Alex reacts to score: thumbs up (2/2) or encouraging expression (1/2)

Screen 9 — SUMMARY + REFLECTION + COMPLETION
- Summary: Three animated cards appear with the V / I / D steps + their one-line on-floor
  application
- Reflection prompt:
  "Think about your last shift. Name one situation where the VID Check would have changed
  your decision."
  → Textarea field (styled to look like a stickynote on a warehouse clipboard)
- Completion: "Mark Complete" button (teal, full-width)
  → Triggers: completion animation (checkmark draws itself, confetti in amber/teal),
    completion badge appears: "VID Check Certified — NAEF Quality Module · [auto-date]"
  → Alex waves goodbye with speech bubble: "See you on the floor."

TECHNICAL REQUIREMENTS
- Single self-contained HTML file, all CSS and JS embedded
- All Google Fonts loaded via link tag (DM Sans + DM Serif Display)
- SVG-rendered warehouse backgrounds (conveyor belts, shelves, ambient lighting) using CSS/SVG —
  no external image dependencies
- Alex avatar: inline SVG character with multiple expression variants (neutral, coaching,
  happy, concerned) switched via JS class changes
- Smooth slide transitions: CSS fade + translateY animation (0.3s ease)
- Progress bar: sticky header, 9-step dot indicators, fills with amber on completion
- Locked navigation: scenario and quiz slides cannot advance until interaction is complete
- Mobile-responsive: readable and functional on tablet/mobile
- No external libraries or CDN dependencies except Google Fonts
```

---

## DELIVERABLE 2 — PARTICIPANT GUIDE (HTML Artifact)

### Paste this prompt to build the participant guide:

```
Build a production-grade HTML participant guide to accompany the NAEF "Catch It Before It Ships"
eLearning module. Use the context block at the top of this conversation. This is a portfolio piece
for an Amazon Learning Experience Designer interview — it must look and feel like a real
enterprise L&D document.

VISUAL DESIGN
Match the eLearning course aesthetic exactly:
- Same dark navy (#0F1F3D) cover header with amber (#E8A020) accent
- Same typography: DM Serif Display (headings) + DM Sans (body)
- Same teal (#1A7A5E) for correct/success indicators
- Clean white content sections on light gray (#F2F3F6) background
- "Alex" avatar appears as a small SVG figure at key moments with short coaching callouts
- Print-optimized: clean layout that prints well (use @media print)

GUIDE SECTIONS

1. COVER PAGE
   - Dark navy header, matching eLearning title treatment
   - Course title: "Catch It Before It Ships" (DM Serif Display)
   - Subtitle: "Quality Defect Prevention — NAEF Associates"
   - Participant name field (write-in line)
   - Metadata: Program | Duration | Site | Date (fill-in fields)
   - Small tag: "NAEF L&D · 2026 Quality Strategy"

2. ABOUT THIS MODULE
   - 2-paragraph context: what this module is, why quality defect reduction is a 2026 NAEF
     priority, how the participant guide is designed to be used (during module + on floor)
   - Small "How to use this guide" box: icons for During Module / On the Floor / Debrief

3. LEARNING OBJECTIVES
   - 3 behavioral objectives (same as the course)
   - Each objective includes:
     → The observable behavior
     → The on-floor measurement method
     → The Kirkpatrick level (L2 for knowledge check, L3 for behavior observation)

4. VID CHECK JOB AID — FULL SIZE
   - Navy-bordered, printable job aid block
   - V / I / D rows with: step letter, step name, what to check, decision criteria
     (Release / Fix / Flag with clear if/then triggers for each)
   - "Tear out and post at your station" instruction
   - Alex callout: "I've had this on my station for 4 years. It still helps."

5. SCENARIO 1 SUMMARY — "The Dented Box"
   - Scene recap (2 sentences)
   - Best decision + why (VID Check application, step by step)
   - What the wrong choice costs (return + reship + customer review impact)
   - Reflection space: "Describe a similar situation from your own experience. What would
     you do differently now?" (lined write-in space)

6. SCENARIO 2 SUMMARY — "The Peak Crunch"
   - Same structure as Scenario 1
   - Focus on: how pressure changes decision-making, and why the VID Check is the
     Peak-season tool specifically
   - Reflection space: "Think about your last high-volume shift. Where was the quality
     decision hardest to make?"

7. YOUR 3-DAY APPLICATION PLAN
   - Day 1: Apply the VID Check to every ambiguous item — building habit
   - Day 2: Apply under rate pressure — notice the pull to skip, use it as the trigger
   - Day 3: Capture one real situation where the VID Check changed your decision —
     bring it to your manager debrief
   - Each day has a write-in action commitment field and a reflection line

8. MANAGER DEBRIEF GUIDE
   - 5 structured debrief questions (numbered, with brief facilitator notes)
   - Observation metric: "Target 90%+ VID Check compliance on ambiguous items within
     5 business days of training" — with a simple observation checklist table
   - Note: "This debrief is a Kirkpatrick Level 3 measurement tool — not a quiz review."

9. QUICK REFERENCE CARD (bottom of guide, styled as tear-out)
   - Compact VID Check: V / I / D in 30 words total
   - "The rule": If you're asking yourself 'is this fine?' — that question is the trigger.
     Run the check.
   - Dark navy background, amber and teal accents — matches eLearning visual language

TECHNICAL
- Single self-contained HTML file
- Google Fonts: DM Sans + DM Serif Display
- Print stylesheet: remove backgrounds on body, preserve navy/teal on headers,
  ensure all write-in fields print with visible borders
- Alex SVG avatar: simplified version (smaller, just head + vest) at 3-4 callout points
```

---

## DELIVERABLE 3 — DESIGN PROCESS DOCUMENT (HTML Artifact)

### Paste this prompt to build the design document:

```
Build a polished HTML document that presents my instructional design thought process for the
"Catch It Before It Ships" NAEF quality defect reduction module. This is a portfolio piece for
an Amazon Learning Experience Designer interview. The document should read like a professional
design rationale — showing my learning science thinking, not just what I built.

This document demonstrates my full design process, from needs analysis through evaluation
planning. It should show I think in behavior change and measurement, not content delivery.

VISUAL DESIGN
- Professional and clean: white background, dark navy (#0F1F3D) section headers,
  amber (#E8A020) for process step indicators, teal (#1A7A5E) for decision highlights
- Typography: DM Serif Display for section titles, DM Sans for body
- Timeline/process indicator at top: horizontal steps showing the phases
- Print-friendly layout

DOCUMENT SECTIONS

SECTION 1 — NEEDS ANALYSIS
Title: "Starting with the performance gap, not the training request"

Subsections:
A) Strategic Context
   - NAEF 2026 L&D strategy: four pillars (role readiness, cross-skilling, quality defect
     reduction, facilitator certification)
   - Why quality defect reduction was selected for this module: highest tie to measurable
     business outcomes, most actionable at the associate level, strongest behavioral design
     opportunity
   - Design question posed: "What behavior needs to change at the station, and what's
     currently stopping associates from making the right decision?"

B) Performance Gap Analysis
   - Gap identified: Associates lack a structured decision tool for ambiguous quality
     situations — the gap is not knowledge (they know defects are bad) but decision fluency
     under pressure
   - Root cause: Rate pressure and social pressure create a "move-past-it" default behavior
     at exactly the moments when quality decisions are most critical
   - Insight: "Downstream QA will catch it" is the cognitive distortion this training targets

C) Audience Analysis
   - Primary: FC associates at pick, pack, stow — direct handling of items before shipment
   - Secondary: Supervisors and shift leads who run post-training observation and debrief
   - Motivation factors: Associates are motivated by not making mistakes, not by policy
     compliance — design must address the emotional reality of rate pressure

D) Training vs. Non-Training Solutions
   - Table showing what training CAN address vs. what requires system/process intervention
   - Design decision: Training is the right solution for decision fluency, not for
     systemic rate pressure — the course acknowledges that tension rather than ignoring it

SECTION 2 — LEARNING DESIGN DECISIONS
Title: "Why these design choices — and what they're built to do"

Include each of the following decisions with rationale:

A) Scenario-based design (not lecture + quiz)
   - Rationale: Cognitive load theory + transfer-appropriate processing — adults learn
     decision-making by practicing decisions, not reading about them
   - Evidence base: Scenario-based training is significantly more effective for procedural
     and judgment tasks than content-first instruction (cite as "consistent with research
     in situated cognition and deliberate practice")

B) The VID Check framework
   - Why a framework: Reduces cognitive load in high-pressure moments — replaces "what
     should I do?" with "which step am I on?"
   - Why 3 steps: Dual coding + working memory constraints — 3 items is the practical
     limit for a tool meant to be used under time pressure
   - Naming rationale: Acronym-based frameworks improve recall and on-the-floor application
     vs. procedural checklists

C) Pressure-realistic scenarios
   - Scenario 1 includes rate pressure (8% below target)
   - Scenario 2 stacks three pressures (volume, rate mentions, social)
   - Rationale: Transfer is most likely when training conditions match performance conditions
     (Bjork's desirable difficulties; contextual interference research)
   - Design choice: Scenarios do NOT present ideal conditions — they present real ones

D) Branching with consequence framing
   - Wrong answers show consequences (defect escapes, customer impact, cost)
   - Not "that's incorrect, try again" — but "here's what this decision costs"
   - Rationale: Emotional salience increases memory encoding (affect and learning research)
   - Design choice: Partial credit choice (Scenario 1, Choice C) validates escalation
     instinct while redirecting to the more complete behavior

E) Instructor avatar "Alex"
   - Alex is a peer, not a lecturer or corporate voice
   - Rationale: Social modeling (Bandura) — observing a respected peer demonstrate the
     behavior increases adoption vs. authority-figure instruction
   - Alex's failure story (shipped 3 defective items) is deliberate: it normalizes the
     problem and reduces shame-based avoidance

F) Reflection field at completion
   - Rationale: Generative retrieval — asking learners to connect content to their own
     experience strengthens encoding (Roediger & Karpicke, 2006)
   - Design choice: Reflection is anchored to "last shift" — immediate, specific, not abstract

SECTION 3 — CONTENT ARCHITECTURE
Title: "How the module is structured — and why in this order"

Include:
- Screen-by-screen flow diagram (rendered as an HTML/SVG flow showing the 9 screens and
  branching logic)
- Design principle for each phase:
  Phase 1 (Screens 1-3): Motivation + Framework — establish stakes before teaching the tool
  Phase 2 (Screens 4-7): Application — practice in realistic conditions before assessment
  Phase 3 (Screens 8-9): Assessment + Transfer — check knowledge, then bridge to floor behavior

SECTION 4 — EVALUATION PLAN (KIRKPATRICK L1–L4)
Title: "Measuring behavior change, not module completion"

Table format:
- Level 1 (Reaction): In-module reflection field + post-module 2-question pulse
- Level 2 (Learning): Knowledge check score (target: 80%+ on first attempt)
- Level 3 (Behavior): Supervisor observation checklist at 5 days post-training —
  target 90%+ VID Check compliance on ambiguous items
- Level 4 (Results): Quality defect rate at associate level tracked over 30 days —
  target measurable reduction vs. pre-training baseline

Note box: "L3 and L4 measurement requires manager participation — the debrief guide and
observation metric in the participant guide are the tools that make this possible."

SECTION 5 — DEVELOPMENT NOTES
Title: "How this was built and what I'd do at full scale"

Subsections:
A) Prototype approach
   - Built as a single-file HTML prototype to demonstrate interaction design and visual
     fidelity — equivalent to a Storyline 360 prototype at the alpha stage
   - At full scale: would rebuild in Articulate Storyline 360 with Rise 360 companion module
     for reference content; LMS publish to Amazon's Learn platform

B) SME partnership plan
   - For a real production build: 3 SME sessions planned (operations lead for scenario
     validation, QA lead for defect data accuracy, associate focus group for language/tone review)
   - Scenario realism was designed with operational specificity (8% below rate, 40% volume
     increase, stow station context) to model what SME-validated content would look like

C) What I'd iterate based on pilot data
   - If L2 scores are below 80%: add a second practice scenario before the knowledge check
   - If L3 observation shows low compliance at peak specifically: add a Peak Season micromodule
   - If reflection fields are left blank: reconsider reflection format (voice note, manager
     conversation, rather than typed field)

D) Scale considerations
   - Module designed for 102 NAEF sites across 23 countries: language variables noted (tone
     calibrated for plain-language translation), scenarios avoid region-specific cultural cues,
     VID Check framework uses universal icons not text-dependent instruction

DOCUMENT FOOTER
- Author note: "This design document represents the instructional thinking behind a prototype
  module. Full production would involve SME validation, LMS integration, and iterative pilot
  testing. The design decisions documented above are grounded in learning science research
  and applied against real operational constraints."
- Kirkpatrick model credit note
- NAEF L&D · 2026 Quality Strategy

TECHNICAL
- Single HTML file, Google Fonts (DM Sans + DM Serif Display)
- Flow diagram in Section 3 rendered as inline SVG showing screen sequence + branching
- Kirkpatrick table in Section 4 rendered as a styled HTML table (not plain text)
- Print-friendly layout
```

---

## TIPS FOR BEST RESULTS

1. **Build one deliverable at a time** in separate Claude conversations.
   Paste the Context Block + one Deliverable prompt together.

2. **If the course needs iteration**, tell Claude:
   "The warehouse background needs more visual depth — add animated CSS conveyor belt
   motion and overhead lighting glow to every screen."

3. **To get Alex's avatar more detailed**, ask:
   "Redesign Alex's SVG avatar to have more expressive facial features — visible eyes,
   a slight smile, and an Amazon FC orange vest with a name badge reading 'Alex, Trainer'."

4. **To add more scenarios**, tell Claude:
   "Add a third scenario called 'The Wrong Item' — set at the pick station, where the item
   picked doesn't match the order. Apply the same branching structure."

5. **For the participant guide**, if you want Word format instead:
   "Convert this participant guide HTML to a Word document (.docx) using python-docx,
   preserving all section structure and styling."
